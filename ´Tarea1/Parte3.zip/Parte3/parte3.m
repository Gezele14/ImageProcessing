clc; clear;
pkg load image
M = 112*92; %Tamño del vwector imagen
N = 40*9; %cantidad de imagenes
S = A = zeros(M,N); 
f = fprom = zeros(M,1);

%-----------Creacion del espacio---------------------------------
for x = 1:40
  for y = 1:9
    B = imread(['Database/' int2str(x) '_' int2str(y) '.png']);
    B = im2double(B); %Carga y convierte a double la imagen
    f = img2column(B); %Comvierte la matriz de la imagen en vector
    S(:,(x-1)*9+y) = f;
    fprom = fprom + f;
  endfor
endfor

%------------Calcula el vector promedio de imagenes------------
fprom = fprom/N;

%------------Crea la matriz A----------------------
for y = 1:N
  A(:,y) = S(:,y) - fprom;
endfor



[U,E,V] = svd(A);

Z = column2img(U(1,:),112,92);
imshow(Z)